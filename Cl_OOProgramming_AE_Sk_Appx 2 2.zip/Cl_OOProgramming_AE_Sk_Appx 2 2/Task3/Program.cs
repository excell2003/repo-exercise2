﻿using System;
using System.Collections.Generic;

// The Person class is a blueprint for creating people, but you can't create a Person directly.
// Other classes will use this blueprint to create specific types of people.
public abstract class Person
{
    // This variable holds the person's name.
    protected string _name;

    // This is the constructor, which is used to give the person a name when they are created.
    public Person(string name)
    {
        _name = name;
    }

    // This is an abstract method, meaning other classes that inherit from Person must create their own version of this method.
    public abstract void PrintDetails();
}

// The Student class is a specific type of Person.
public class Student : Person
{
    // This array holds the subjects the student is studying.
    private string[] _subjects;

    // When we create a student, we give them a name and a list of subjects.
    public Student(string name, string[] subjects) : base(name)
    {
        _subjects = subjects;
    }

    // This method prints out the student's name and the subjects they are studying.
    public override void PrintDetails()
    {
        // We join the subjects into a single string and print it with the student's name.
        Console.WriteLine($"Hi, my name is {_name} and I am studying {string.Join(", ", _subjects)}");
    }
}

// The Teacher class is another specific type of Person.
public class Teacher : Person
{
    // This variable holds the faculty (department) the teacher works in.
    private string _faculty;

    // When we create a teacher, we give them a name and a faculty.
    public Teacher(string name, string faculty) : base(name)
    {
        _faculty = faculty;
    }

    // This method prints out the teacher's name and their faculty.
    public override void PrintDetails()
    {
        Console.WriteLine($"Hi, my name is {_name} and I teach in the {_faculty} faculty");
    }
}

// This is the main program that will run when we start the application.
class Program
{
    static void Main(string[] args)
    {
        // We create a list that will hold people (both students and teachers).
        List<Person> people = new List<Person>();

        // We create a student named "JESUS" who is studying Math, Science, and English.
        string[] subjects = { "Math", "Science", "English" };
        Student student = new Student("JESUS", subjects);
        // We add this student to our list of people.
        people.Add(student);

        // We create a teacher named "GOD" who works in the Computer Science faculty.
        Teacher teacher = new Teacher("GOD", "Computer Science");
        // We add this teacher to our list of people.
        people.Add(teacher);

        // We loop through each person in our list and ask them to print their details.
        foreach (var person in people)
        {
            person.PrintDetails();
        }
    }
}