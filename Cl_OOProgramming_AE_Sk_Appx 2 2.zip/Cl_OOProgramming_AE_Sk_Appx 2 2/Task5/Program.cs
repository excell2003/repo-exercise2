﻿using System;

class Program
{
    static void Main()
    {
        // String to accumulate all output
        string output = "";

        // Loop through the numbers from 50 down to 25
        for (int number = 50; number >= 25; number--)
        {
            // Start with the current number
            output += $"{number}";

            // Check if the number is a multiple of 3, 5, or both
            if (number % 3 == 0 && number % 5 == 0)
            {
                output += " [3 & 5]";
            }
            else if (number % 3 == 0)
            {
                output += " [3]";
            }
            else if (number % 5 == 0)
            {
                output += " [5]";
            }

            // Add a newline to separate the numbers
            output += "\n";
        }

        // Use Console.WriteLine only once to print all accumulated output
        Console.WriteLine(output);
    }
}

