﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Step 1: let the user to enter a interger value
        Console.Write("Enter an integer value: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        // Step 2: let the user to enter an operator
        Console.Write("Enter an operator [ Subtract - , Plus + , Multiply * or Division / ]: ");
        char operatorChoice = Console.ReadKey().KeyChar;
        Console.WriteLine();

        // Step 3: let the user tp enter the second interger value
        Console.Write("Enter another integer value: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        // Step 4: Display the calculation result in words
        string resultText = CalculateResultInWords(num1, num2, operatorChoice);

        if (resultText != null)
        {
            Console.WriteLine(resultText);
        }
        else
        {
            Console.WriteLine("Invalid operator entered.");
        }
    }

    static string CalculateResultInWords(int num1, int num2, char operatorChoice)
    {
        int result;
        string resultText = null;

        switch (operatorChoice)
        {
            case '+':
                result = num1 + num2;
                resultText = $"{num1} plus {num2} equals {result}";
                break;
            case '-':
                result = num1 - num2;
                resultText = $"{num1} minus {num2} equals {result}";
                break;
            case '*':
                result = num1 * num2;
                resultText = $"{num1} multiplied by {num2} equals {result}";
                break;
            case '/':
                if (num2 != 0)
                {
                    result = num1 / num2;
                    resultText = $"{num1} divided by {num2} equals {result}";
                }
                else
                {
                    resultText = "Division by zero is not allowed.";
                }
                break;
            default:
                resultText = null;
                break;
        }

        return resultText;
    }
}