﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        // Define the input and output file paths
        string inputFilePath = "characters.txt";
        string outputFilePath = "character-count.txt";

        // Ensure the input file exists before proceeding
        if (!File.Exists(inputFilePath))
        {
            Console.WriteLine($"Error: The file {inputFilePath} was not found.");
            return;
        }

        // Read the content of the characters.txt file
        string content = File.ReadAllText(inputFilePath);

        // Initialize an array to hold the count of each letter from A to Z
        int[] letterCounts = new int[26];

        // Iterate through the content and count each alphabetic character
        foreach (char c in content)
        {
            if (c >= 'A' && c <= 'Z')  // Check if the character is an uppercase alphabetic character
            {
                letterCounts[c - 'A']++;  // Increment the corresponding count
            }
        }

        // Write the results to the character-count.txt file
        using (StreamWriter writer = new StreamWriter(outputFilePath))
        {
            for (char letter = 'A'; letter <= 'Z'; letter++)
            {
                int count = letterCounts[letter - 'A'];  // Get the count for this letter
                writer.WriteLine($"{letter}: {count}");  // Write the letter and its count to the file
            }
        }

        Console.WriteLine("Character counts have been written to character-count.txt.");
    }
}
