﻿// Define an array of room names
string[] roomNames = { "single", "double", "luxury", "penthouse" };

// Define an array of room prices corresponding to the array above
double[] roomPrices = { 45.50, 99.99, 165.25, 1095.50 };

// Display the room types and their prices
Console.WriteLine("Room Types");

// Loop through the roomNames array and display each room type with its corresponding price ly looping it with a for loop
for (int i = 0; i < roomNames.Length; i++)
{
    // Print the room number (i+1) along with the room name and price
    Console.WriteLine($"{i + 1}. {roomNames[i]} ${roomPrices[i]} per night");
}

// Ask the user to select a room type by entering a number (1, 2, 3, or 4)
Console.Write("Please select the room type 1, 2, 3 or 4 : ");

// Read the user input, convert it to an integer, and subtract 1 to match the zero-based index of the array
int roomType = int.Parse(Console.ReadLine()) - 1;

// Ask the user to enter the number of nights they want to stay
Console.Write("Please enter the number of nights : ");

// Read the user input and convert it to an integer (number of nights)
int noOfNights = int.Parse(Console.ReadLine());

// Calculate the total cost by multiplying the price of the selected room by the number of nights
double totalCost = roomPrices[roomType] * noOfNights;

// Display the total cost along with a thank you message, mentioning the selected room type and number of nights
Console.WriteLine($"Thank you, the total cost for staying in the {roomNames[roomType]} room for {noOfNights} nights is ${totalCost}");
